#!/usr/bin/env python3
from launch import LaunchDescription
from launch.actions import SetEnvironmentVariable, ExecuteProcess


def generate_launch_description():
    world = "/home/ubuntu/project_openclaw/tools/image2gazebo/result/test_101/20260723_042608/worlds/test_101.world"
    model_root = "/home/ubuntu/project_openclaw/tools/image2gazebo/result/test_101/20260723_042608/model"
    return LaunchDescription([
        SetEnvironmentVariable(name="GAZEBO_MODEL_PATH", value=model_root),
        ExecuteProcess(
            cmd=["gazebo", "--verbose", world, "-s", "libgazebo_ros_factory.so"],
            output="screen",
        ),
    ])
